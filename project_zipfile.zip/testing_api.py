import requests
import json

url = "http://ec2-3-235-60-45.compute-1.amazonaws.com/response"

payload = json.dumps({
  "text": "whos the champion of World cup 2022? dont tell me you dont know"
})
headers = {
  'Content-Type': 'application/json'
}

response = requests.request("POST", url, headers=headers, data=payload)
vals=response.json()

print(vals.keys())
print(vals['response'])